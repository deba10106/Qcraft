# Remove problematic imports to avoid ModuleNotFoundError on package import
# from .orchestrator import Orchestrator
# from . import code_switcher
# from .heuristic_layer.surface_code import SurfaceCode
# from .code_switcher.code_switcher import CodeSwitcher 